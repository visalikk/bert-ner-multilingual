if __name__ == '__main__':
    from .deep import main
    main()
