This skill wraps python-aiml library and allows developer to integrate AIML scripts into DeepPavlov dialog system.

If you'd like to find more free AIML scripts here is link:
https://github.com/pandorabots/Free-AIML 

You can set path to folder with your AIML scripts as config param (see attr `path_to_aiml_scripts`).  