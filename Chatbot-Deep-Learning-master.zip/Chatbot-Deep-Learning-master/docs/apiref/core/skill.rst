deeppavlov.core.skill
=====================
Basic class for building DeepPavlov skills.

.. automodule:: deeppavlov.core.skill.skill
   :members:
