deeppavlov.core.trainers
========================
Trainer classes.

.. autoclass:: deeppavlov.core.trainers.FitTrainer
   :members:

.. autoclass:: deeppavlov.core.trainers.NNTrainer
   :members:
   :inherited-members:
