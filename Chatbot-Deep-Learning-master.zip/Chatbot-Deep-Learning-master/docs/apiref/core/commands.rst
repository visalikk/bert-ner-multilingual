deeppavlov.core.commands
========================
Basic training and inference functions.

.. automodule:: deeppavlov.core.commands.infer
   :members:

.. automodule:: deeppavlov.core.commands.train
   :members:
