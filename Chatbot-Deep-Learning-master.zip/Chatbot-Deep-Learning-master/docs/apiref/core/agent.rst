deeppavlov.core.agent
=====================
Basic classes for building DeepPavlov agents.

.. automodule:: deeppavlov.core.agent.agent
   :members:

.. automodule:: deeppavlov.core.agent.dialog_logger
   :members:

.. automodule:: deeppavlov.core.agent.filter
   :members:

.. automodule:: deeppavlov.core.agent.processor
   :members:

.. automodule:: deeppavlov.core.agent.rich_content
   :members:
