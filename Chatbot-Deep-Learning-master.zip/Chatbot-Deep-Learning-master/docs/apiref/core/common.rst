deeppavlov.core.common
======================
Registration and classes initialization functionality, class method decorators.

.. automodule:: deeppavlov.core.common.chainer
   :members:

.. autoclass:: deeppavlov.core.common.chainer.Chainer
   :members:

   .. automethod:: __call__

.. automodule:: deeppavlov.core.common.metrics_registry
   :members:

.. automodule:: deeppavlov.core.common.params
   :members:

.. automodule:: deeppavlov.core.common.registry
   :members:
