deeppavlov.skills.aiml_skill
========================================

.. automodule:: deeppavlov.skills.aiml_skill.aiml_skill
   :members:
