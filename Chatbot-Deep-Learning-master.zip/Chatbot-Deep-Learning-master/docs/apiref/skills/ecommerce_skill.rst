deeppavlov.skills.ecommerce_skill
=================================

.. automodule:: deeppavlov.skills.ecommerce_skill.tfidf_retrieve
   :members:
