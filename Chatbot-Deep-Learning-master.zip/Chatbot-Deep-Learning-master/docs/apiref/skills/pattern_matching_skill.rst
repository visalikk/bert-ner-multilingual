deeppavlov.skills.pattern_matching_skill
========================================

.. automodule:: deeppavlov.skills.pattern_matching_skill.pattern_matching_skill
   :members:
