deeppavlov.skills.default_skill
===============================
Skill used for wrapping DeepPavlov components.

.. automodule:: deeppavlov.skills.default_skill.default_skill
   :members:
