skills
======
Skill classes. Skills are dialog models.

.. automodule:: deeppavlov.skills
   :members:

.. toctree::
   :glob:
   :caption: Skills

   skills/*