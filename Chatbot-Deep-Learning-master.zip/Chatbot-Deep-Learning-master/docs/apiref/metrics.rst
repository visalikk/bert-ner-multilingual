metrics
=======
Different Metric functions.

.. automodule:: deeppavlov.metrics
   :members:

.. autofunction:: deeppavlov.metrics.accuracy.sets_accuracy

.. autofunction:: deeppavlov.metrics.fmeasure.round_f1

.. autofunction:: deeppavlov.metrics.fmeasure.round_f1_macro

.. autofunction:: deeppavlov.metrics.fmeasure.round_f1_weighted

.. autofunction:: deeppavlov.metrics.log_loss.sk_log_loss

.. autofunction:: deeppavlov.metrics.roc_auc_score.roc_auc_score
