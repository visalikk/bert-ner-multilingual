deeppavlov.agents.hello_bot_agent
=================================
Simple hello bot agent built on pattern matching skill.

.. automodule:: deeppavlov.agents.hello_bot_agent.hello_bot_agent
   :members:
