deeppavlov.agents.filters
=========================
Filters for default agent.

.. automodule:: deeppavlov.agents.filters.transparent_filter
   :members:
