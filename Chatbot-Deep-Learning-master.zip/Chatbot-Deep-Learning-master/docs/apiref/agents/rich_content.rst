deeppavlov.agents.rich_content
==============================
Rich content support implemented for various channels.

.. automodule:: deeppavlov.agents.rich_content.default_rich_content
   :members:
