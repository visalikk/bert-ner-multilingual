deeppavlov.agents.default_agent
===============================
Default agent with filters and processors support.

.. automodule:: deeppavlov.agents.default_agent.default_agent
   :members:
