vocabs
======
Concrete Vocab classes.

.. automodule:: deeppavlov.vocabs
   :members:

.. autoclass:: deeppavlov.vocabs.wiki_sqlite.WikiSQLiteVocab
   :members:

   .. automethod:: __call__

.. automodule:: deeppavlov.vocabs.typos
   :members:
