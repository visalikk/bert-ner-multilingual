core
====
DeepPavlov Core

.. automodule:: deeppavlov.core
   :members:

.. toctree::
   :glob:
   :caption: Core

   core/*
