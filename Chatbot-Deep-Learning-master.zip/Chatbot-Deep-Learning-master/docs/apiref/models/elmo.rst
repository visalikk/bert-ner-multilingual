deeppavlov.models.elmo
======================

.. automodule:: deeppavlov.models.elmo

.. autoclass:: deeppavlov.models.elmo.elmo.ELMo
