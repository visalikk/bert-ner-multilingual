deeppavlov.models.slotfill
==========================

.. autoclass:: deeppavlov.models.slotfill.slotfill.DstcSlotFillingNetwork

.. autoclass:: deeppavlov.models.slotfill.slotfill_raw.SlotFillingComponent
