deeppavlov.models.kbqa
======================

.. automodule:: deeppavlov.models.kbqa

.. autoclass:: deeppavlov.models.kbqa.kb_answer_parser_wikidata.KBAnswerParserWikidata
