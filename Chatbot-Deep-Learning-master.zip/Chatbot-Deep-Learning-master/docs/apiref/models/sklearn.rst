deeppavlov.models.sklearn
=============================

.. automodule:: deeppavlov.models.sklearn
   :members:

.. autoclass:: deeppavlov.models.sklearn.sklearn_component.SklearnComponent

    .. automethod:: __call__
    .. automethod:: fit
    .. automethod:: init_from_scratch
    .. automethod:: load
    .. automethod:: save
    .. automethod:: compose_input_data
    .. automethod:: get_class_attributes
    .. automethod:: get_function_params
