deeppavlov.models.vectorizers
=============================


.. autoclass:: deeppavlov.models.vectorizers.hashing_tfidf_vectorizer.HashingTfIdfVectorizer
    :members:

    .. automethod:: __call__

.. autoclass:: deeppavlov.models.vectorizers.word_vectorizer.DictionaryVectorizer
    :members:

    .. automethod:: __call__

.. autoclass:: deeppavlov.models.vectorizers.word_vectorizer.PymorphyVectorizer
    :members:

    .. automethod:: __call__

