deeppavlov.models.ner
=====================

.. autoclass:: deeppavlov.models.ner.network.NerNetwork
