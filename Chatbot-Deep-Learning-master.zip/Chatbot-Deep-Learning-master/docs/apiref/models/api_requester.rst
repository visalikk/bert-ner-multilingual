deeppavlov.models.api_requester
===============================

.. automodule:: deeppavlov.models.api_requester
    :members:

.. autoclass:: deeppavlov.models.api_requester.api_requester.ApiRequester

    .. automethod:: __call__
    .. automethod:: get_async_response


.. autoclass:: deeppavlov.models.api_requester.api_router.ApiRouter

    .. automethod:: __call__
