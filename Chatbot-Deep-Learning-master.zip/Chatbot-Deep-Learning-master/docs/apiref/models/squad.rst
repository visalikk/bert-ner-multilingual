deeppavlov.models.squad
=====================================
.. automodule:: deeppavlov.models.squad.squad

.. autoclass:: deeppavlov.models.squad.squad.SquadModel

    .. automethod:: __call__
    .. automethod:: train_on_batch
    .. automethod:: process_event
