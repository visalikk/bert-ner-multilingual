deeppavlov.models.go_bot
========================

.. automodule:: deeppavlov.models.go_bot

.. autoclass:: deeppavlov.models.go_bot.network.GoalOrientedBot
   :members:

.. autoclass:: deeppavlov.models.go_bot.tracker.Tracker

.. autoclass:: deeppavlov.models.go_bot.tracker.DefaultTracker

.. autoclass:: deeppavlov.models.go_bot.tracker.FeaturizedTracker
